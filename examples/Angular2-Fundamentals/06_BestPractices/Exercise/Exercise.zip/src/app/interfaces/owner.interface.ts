export interface Owner {
  id: number;
  name: string;
  image: string;
  carsOwned: number;
}
